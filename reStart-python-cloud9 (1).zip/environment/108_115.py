# myValue=True
# print(myValue)
# print(type(myValue))
# print(str(myValue) + " is of the data type " + str(type(myValue)))

#2
# myValue=False
# print(myValue)
# print(type(myValue))
# print(str(myValue) + " is of the data type " + str(type(myValue)))

#3
# myString = "This is a string."
# print(myString)
# print(type(myString))
# print(myString + " is of the data type " + str(type(myString)))

# 4.Working with string concatenation
# firstString = "water"
# secondString = "fall"
# thirdString = firstString + secondString
# print(thirdString)

# Exercise 3: Working with input strings
# name = input("What is your name? ")
# print(name)

# Exercise 4: Formatting output strings
# color = input("What is your favorite color?  ")
# animal = input("What is your favorite animal?  ")
# print("{}, you like a {} {}!".format(name,color,animal))


# Exercise 1: Introducing the list data type
# myFruitList = ["apple", "banana", "cherry"]
# print(myFruitList)
# print(type(myFruitList))
# print(myFruitList[0])
# print(myFruitList[1])
# print(myFruitList[2])

# myFruitList[2] = "orange"
# print(myFruitList)



# Exercise 2: Introducing the tuple data type
# myFinalAnswerTuple = ("apple", "banana", "pineapple")
# print(myFinalAnswerTuple)
# print(type(myFinalAnswerTuple))
# print(myFinalAnswerTuple[0])
# print(myFinalAnswerTuple[1])
# print(myFinalAnswerTuple[2])



# Exercise 3: Introducing the dictionary data type

# myFavoriteFruitDictionary = {
#   "Akua" : "apple",
#   "Saanvi" : "banana",
#   "Paulo" : "pineapple"
# }


# print(myFavoriteFruitDictionary)
# print(type(myFavoriteFruitDictionary))
# print(myFavoriteFruitDictionary["Akua"])
# print(myFavoriteFruitDictionary["Saanvi"])
# print(myFavoriteFruitDictionary["Paulo"])


# Exercise 1: Creating a mixed-type list

myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))





